# E32-TTL-100_ArduinoIDE
E32-TTL-100_Arduino_Testing Program


The Draft Example is those path for me to develop the process.
The E32_Lib is the library I write for Arduino IDE.

Debug program: RealTerm, HTerm

Hardware: https://yibaite.tmall.com/search.htm?spm=a220m.1000858.1000725.3.2db25f33Ivq4kW&user_number_id=2201474289139&rn=a8201633288fb8fa964cf78b6ef80f4b&keyword=ebyte
